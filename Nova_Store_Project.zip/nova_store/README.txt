# Nova Store

A beginner-friendly front-end shopping website built with HTML, CSS and JavaScript.

## Run it
1. Extract the ZIP file.
2. Open the `nova_store` folder.
3. Double-click `index.html` to open it in your browser.

You can also open the folder in Visual Studio Code and use the Live Server extension.

## Customize products
Open `script.js` and edit the `products` array near the top. Each product has:
- `id`: a unique number
- `name`: product name
- `category`: Gaming, Fashion, Tech, Accessories or Home
- `price`: price in DT
- `emoji`: product illustration
- `description`: short description
- `color`: product-card background color
- `tag`: optional label

## Important
This is a front-end demo. Cart and favorites are saved in the browser using localStorage. Checkout is only a demo; it does not collect payment details, create real orders, or protect customer information. Before selling for real, you need a secure backend, order management, hosting, privacy information, and a trusted payment provider. Ask a parent/guardian to help with business and payment accounts.
