// Nova Store demo data. Change these products to customize your shop.
const products = [
  {id:1,name:"Nova RGB Headset",category:"Gaming",price:89,emoji:"🎧",description:"Comfortable sound for your next game.",color:"#eee5ff",tag:"BESTSELLER"},
  {id:2,name:"Mechanical Keyboard",category:"Gaming",price:149,emoji:"⌨️",description:"Colorful keys and satisfying clicks.",color:"#ffe5ef",tag:"POPULAR"},
  {id:3,name:"Wireless Gaming Mouse",category:"Gaming",price:79,emoji:"🖱️",description:"Lightweight and ready for action.",color:"#e1f7f1",tag:"NEW"},
  {id:4,name:"Classic Street Sneakers",category:"Fashion",price:179,emoji:"👟",description:"Everyday comfort with fresh style.",color:"#fff0d5",tag:"TRENDING"},
  {id:5,name:"Nova Oversized Hoodie",category:"Fashion",price:119,emoji:"👕",description:"A cozy layer for cool days.",color:"#e8eaff",tag:"NEW"},
  {id:6,name:"Smart Watch",category:"Tech",price:229,emoji:"⌚",description:"A handy companion for every day.",color:"#e2f4ff",tag:"POPULAR"},
  {id:7,name:"Wireless Earbuds",category:"Tech",price:99,emoji:"🎵",description:"Your music, wherever you go.",color:"#ffe7e0",tag:"BESTSELLER"},
  {id:8,name:"Mini Desk Lamp",category:"Home",price:59,emoji:"💡",description:"A bright idea for your workspace.",color:"#fff5cf",tag:""},
  {id:9,name:"Cute Phone Case",category:"Accessories",price:29,emoji:"📱",description:"Give your phone a little personality.",color:"#fce4f3",tag:""},
  {id:10,name:"Everyday Backpack",category:"Accessories",price:109,emoji:"🎒",description:"Room for your daily essentials.",color:"#e6f4e8",tag:"POPULAR"},
  {id:11,name:"Portable Speaker",category:"Tech",price:139,emoji:"🔊",description:"Bring good vibes to any room.",color:"#e9e2ff",tag:""},
  {id:12,name:"Cozy Cushion",category:"Home",price:49,emoji:"🛋️",description:"A soft touch for your favorite corner.",color:"#ffe9dc",tag:""}
];

let cart = JSON.parse(localStorage.getItem("novaCart") || "[]");
let favorites = JSON.parse(localStorage.getItem("novaFavorites") || "[]");
let selectedCategory = "All";
let showFavoritesOnly = false;

const productGrid = document.getElementById("productGrid");
const searchInput = document.getElementById("searchInput");
const sortSelect = document.getElementById("sortSelect");
const emptyState = document.getElementById("emptyState");
const resultText = document.getElementById("resultText");
const cartDrawer = document.getElementById("cartDrawer");
const overlay = document.getElementById("overlay");
const toast = document.getElementById("toast");

function money(amount){ return `${amount.toFixed(2)} DT`; }
function saveData(){
  localStorage.setItem("novaCart",JSON.stringify(cart));
  localStorage.setItem("novaFavorites",JSON.stringify(favorites));
}
function notify(message){
  toast.textContent=message; toast.classList.add("show");
  clearTimeout(notify.timer); notify.timer=setTimeout(()=>toast.classList.remove("show"),2000);
}
function renderProducts(){
  const search=searchInput.value.trim().toLowerCase();
  let shown=products.filter(p=>(selectedCategory==="All"||p.category===selectedCategory)&&
    (p.name.toLowerCase().includes(search)||p.category.toLowerCase().includes(search)||p.description.toLowerCase().includes(search))&&
    (!showFavoritesOnly||favorites.includes(p.id)));
  if(sortSelect.value==="low") shown.sort((a,b)=>a.price-b.price);
  if(sortSelect.value==="high") shown.sort((a,b)=>b.price-a.price);
  if(sortSelect.value==="name") shown.sort((a,b)=>a.name.localeCompare(b.name));
  productGrid.innerHTML=shown.map(p=>`
    <article class="product-card">
      <div class="product-art" style="background:${p.color}">
        ${p.tag?`<small>${p.tag}</small>`:""}
        <button class="favorite-button ${favorites.includes(p.id)?"saved":""}" data-favorite="${p.id}" aria-label="Add ${p.name} to favorites">${favorites.includes(p.id)?"♥":"♡"}</button>
        <span>${p.emoji}</span>
      </div>
      <div class="product-info">
        <div class="product-category">${p.category}</div><h3>${p.name}</h3>
        <p class="product-description">${p.description}</p>
        <div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add-button" data-add="${p.id}">+ Add</button></div>
      </div>
    </article>`).join("");
  emptyState.classList.toggle("hidden",shown.length!==0);
  resultText.textContent=showFavoritesOnly?`${shown.length} saved favorite(s).`:`Showing ${shown.length} product(s).`;
}
function addToCart(id){
  const item=cart.find(x=>x.id===id);
  if(item)item.quantity++; else cart.push({id,quantity:1});
  saveData();renderCart();notify("Added to your cart!");
}
function changeQuantity(id,amount){
  const item=cart.find(x=>x.id===id);if(!item)return;
  item.quantity+=amount;if(item.quantity<=0)cart=cart.filter(x=>x.id!==id);
  saveData();renderCart();
}
function renderCart(){
  const count=cart.reduce((sum,x)=>sum+x.quantity,0);
  document.getElementById("cartCount").textContent=count;
  document.getElementById("favoriteCount").textContent=favorites.length;
  const cartItems=document.getElementById("cartItems");
  if(!cart.length){cartItems.innerHTML='<div class="cart-empty">🛍️<h3>Your cart is empty</h3><p>Add something you love!</p></div>';}
  else cartItems.innerHTML=cart.map(item=>{
    const p=products.find(x=>x.id===item.id);if(!p)return "";
    return `<div class="cart-line"><div class="cart-thumb" style="background:${p.color}">${p.emoji}</div>
      <div><h4>${p.name}</h4><small>${money(p.price)} each</small><div class="quantity">
      <button data-change="${p.id}" data-amount="-1">−</button><span>${item.quantity}</span><button data-change="${p.id}" data-amount="1">+</button></div></div>
      <button class="remove-button" data-remove="${p.id}">Remove</button></div>`;
  }).join("");
  const total=cart.reduce((sum,item)=>{const p=products.find(x=>x.id===item.id);return sum+(p?p.price*item.quantity:0);},0);
  document.getElementById("cartTotal").textContent=money(total);
}
function openCart(){cartDrawer.classList.add("open");overlay.classList.remove("hidden");cartDrawer.setAttribute("aria-hidden","false");}
function closeCart(){cartDrawer.classList.remove("open");overlay.classList.add("hidden");cartDrawer.setAttribute("aria-hidden","true");}

productGrid.addEventListener("click",e=>{
  const add=e.target.closest("[data-add]");const fav=e.target.closest("[data-favorite]");
  if(add)addToCart(Number(add.dataset.add));
  if(fav){const id=Number(fav.dataset.favorite);favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];saveData();renderProducts();renderCart();}
});
document.getElementById("cartItems").addEventListener("click",e=>{
  const change=e.target.closest("[data-change]");const remove=e.target.closest("[data-remove]");
  if(change)changeQuantity(Number(change.dataset.change),Number(change.dataset.amount));
  if(remove){cart=cart.filter(x=>x.id!==Number(remove.dataset.remove));saveData();renderCart();}
});
document.querySelectorAll(".category-tile").forEach(button=>button.addEventListener("click",()=>{
  selectedCategory=button.dataset.category;showFavoritesOnly=false;
  document.querySelectorAll(".category-tile").forEach(x=>x.classList.toggle("active",x===button));
  document.getElementById("favoritesButton").style.color="";
  renderProducts();
}));
searchInput.addEventListener("input",renderProducts);
sortSelect.addEventListener("change",renderProducts);
document.getElementById("cartButton").addEventListener("click",openCart);
document.getElementById("closeCart").addEventListener("click",closeCart);
overlay.addEventListener("click",closeCart);
document.getElementById("favoritesButton").addEventListener("click",()=>{
  showFavoritesOnly=!showFavoritesOnly;selectedCategory="All";
  document.querySelectorAll(".category-tile").forEach(x=>x.classList.toggle("active",x.dataset.category==="All"));
  document.getElementById("favoritesButton").style.color=showFavoritesOnly?"#f04d91":"";
  renderProducts();
});
document.getElementById("checkoutButton").addEventListener("click",()=>{
  if(!cart.length){notify("Your cart is empty.");return;}
  closeCart();document.getElementById("checkoutModal").classList.remove("hidden");
});
function closeCheckout(){document.getElementById("checkoutModal").classList.add("hidden");}
document.getElementById("closeCheckout").addEventListener("click",closeCheckout);
document.getElementById("finishCheckout").addEventListener("click",closeCheckout);

renderProducts();renderCart();
